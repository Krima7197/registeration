//
//  FormControls.swift
//  RegistrationFormDemo
//
//  Created by TOPS on 8/31/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class FormControls: NSObject
{
    func textFiled(frm:CGRect,place:String,img:UIImage?,ifrm:CGRect?,keyboard:UIKeyboardType,bgcolor:UIColor?,borcolor:UIColor?,tcolor:UIColor?) -> UITextField
    {
        let txt = UITextField(frame: frm)
        txt.placeholder = place
        txt.backgroundColor = bgcolor
        txt.textColor = tcolor
        let imageview = UIImageView(frame: ifrm!)
        imageview.image = img
        txt.leftViewMode = .always
        txt.leftView = imageview
        
        let border = CALayer()
        let width =  CGFloat(2.0)
        border.borderColor = borcolor?.cgColor
        border.frame=CGRect(x: 0, y: txt.frame.size.height-width, width: txt.frame.size.width, height: txt.frame.size.height)
        border.borderWidth = width
        txt.layer.addSublayer(border)
        txt.layer.masksToBounds = true
        return txt
    }
    func createbtn(frm:CGRect,title:String,bcolor:UIColor?) -> UIButton
    {
        let btn = UIButton(frame: frm)
        btn.setTitle(title, for: .normal)
        btn.backgroundColor = bcolor
        return  btn
    }
    
}

